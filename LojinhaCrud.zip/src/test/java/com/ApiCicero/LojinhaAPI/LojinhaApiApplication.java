package com.ApiCicero.LojinhaAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojinhaApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(LojinhaApiApplication.class, args);
    }
}
